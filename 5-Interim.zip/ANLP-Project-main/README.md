# ANLP-Project - SemEval 2025 - Task 8: Question Answering over Tabular Data

## File structure:
- `installing_ollama.sh:` Installs ollama.
- `ollama_codellama.py:` This is the implementation of the baseline scripts.
- `predictions.txt:` This is the file where we are saving the outputs from DataBench.
- `predictions_lite.txt:` This is the file where we are saving the outputs from DataBench_lite.
